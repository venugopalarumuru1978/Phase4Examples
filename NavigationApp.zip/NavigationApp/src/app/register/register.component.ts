import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  country:string="";

  cities:string[] =["Hyderabad", "Bangalore", "Pune", "Mumbai", "Kolkatta"];
  
  constructor() { }

  ngOnInit(): void {
  }

}
