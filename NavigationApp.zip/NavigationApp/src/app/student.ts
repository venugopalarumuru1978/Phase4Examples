export class Student {

    sname:string;
    exam:string;
    sub1:number;
    sub2:number;
    total:number;
    result:string;

    
}
