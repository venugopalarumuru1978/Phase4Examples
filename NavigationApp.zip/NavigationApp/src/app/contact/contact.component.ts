import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  empinfo:Employee[] = [
    new Employee(101, "Kiran", "Manager", 12000.00),
    new Employee(102, "Karan", "Developer", 11000.00),
    new Employee(103, "Kiranmayee", "Tester", 10000.00),
    new Employee(104, "Komali", "HR_Manager", 15000.00),
    new Employee(105, "Kalyani", "Developer", 11000.00)
  ];

  newemp:Employee= new Employee(0,"","", 0.0);

  AddNewEmployee()
  {
    this.empinfo.push(new Employee(this.newemp.empno, this.newemp.ename, this.newemp.job, this.newemp.sal));

    this.newemp.empno =0;
    this.newemp.ename = "";
    this.newemp.job = "";
    this.newemp.sal = 0.0;
  }

  DeleteEmployee(i:any)
  {
    this.empinfo.splice(i,1);
  }
  constructor() { }

  ngOnInit(): void {
  }

}
