import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  personName : string = "Ravi Kiran";
  salary:number = 30000.00;
  dt:Date = new Date();
  person:object = {fname:"Venugopal", lname:"Arumuru"};
  n:number=4500000;
  val:number = 0.2
  
  constructor() { }

  ngOnInit(): void {
  }

}
