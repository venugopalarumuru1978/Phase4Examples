export class Employee {

    empno:number;
    ename:string;
    job:string;
    sal:number;

    constructor(en:number, ena:string, jb:string, sl:number)
    {
        this.empno = en;
        this.ename = ena;
        this.job = jb;
        this.sal = sl;
    }
}
