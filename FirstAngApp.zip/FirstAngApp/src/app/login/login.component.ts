import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  uname:string = "";
  pwd:string = "";
  msg :string = "";
  
  constructor() { }

  ngOnInit(): void {
  }

  checkLogin()
  {
    if(this.uname=="venugopal" && this.pwd=="12345")
      this.msg = "Login Details are Correct";
    else
      this.msg = "Please check username / password";
  }

}
