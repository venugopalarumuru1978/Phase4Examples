import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-test2',
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.css']
})
export class Test2Component implements OnInit {

  personname:string = "Surya";
  age:number = 20;
  bike:boolean = true;
  gender:string = "Male";
  country :string = "India";
  url:string = "http://www.abc.com";


  changeData()
  {
    this.personname="Vahini Devi";
    this.age = 34;
    this.gender = "Female";
    this.country = "USA";
    this.url = "http://www.vahini.com";
    this.bike = true;
  }
  constructor() { }

  ngOnInit(): void {
  }

}
