import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test1',
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.css']
})
export class Test1Component implements OnInit {

  sname:string="Praveen Kumar";
  loc:string = "Hyderabad";

  constructor() { }

  ngOnInit(): void {
  }

  demofun()
  {
    alert("this is function");
  }
}
