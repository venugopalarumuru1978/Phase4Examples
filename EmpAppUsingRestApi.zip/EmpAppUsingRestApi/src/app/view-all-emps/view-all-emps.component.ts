import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-view-all-emps',
  templateUrl: './view-all-emps.component.html',
  styleUrls: ['./view-all-emps.component.css']
})
export class ViewAllEmpsComponent implements OnInit {
  empinfo:Employee[];
  firstName:any;
  constructor(private empServ:EmployeeService,
    private router:Router
    ) { }

  ngOnInit(): void {
    this.ShowAllEmployees();
  }

  ShowAllEmployees()
  {
    this.empServ.getAllEmployees().subscribe(data=>{
      this.empinfo = data;
    });
  }

  Search()
  {
    if(this.firstName=="")
    {
      this.ShowAllEmployees();
    }
    else
    {
      this.empinfo = this.empinfo.filter(res=>{
        return res.firstName.toLocaleLowerCase().match(this.firstName);
      });
    }
  }


  deleteEmpDetails(id:number)
  {
    this.empServ.deleteEmployeeBasedOnID(id).subscribe(data=>{
      this.ShowAllEmployees();
      //alert(data);
      console.log(data);
    });
  }

  updateEmpDetails(id:number)
  {
    this.router.navigate(['/updateemp', id]);
  }

  viewEmpInfoBasedOnId(id:number)
  {
    this.router.navigate(['/oneemp', id]);
  }
}
