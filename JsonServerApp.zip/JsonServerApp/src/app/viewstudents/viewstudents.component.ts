import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-viewstudents',
  templateUrl: './viewstudents.component.html',
  styleUrls: ['./viewstudents.component.css']
})
export class ViewstudentsComponent implements OnInit {

  stdinfo:Observable<any>;

  constructor(
    private stdService:StudentService, 
    private router:Router
  ) { }

  ngOnInit(): void {
    // this method will be executed only once when page is initlized
    this.viewAllStudentsInfo();
  }


  viewAllStudentsInfo()
  {
    this.stdinfo = this.stdService.ViewAllStudentsInfo();
    
    /*
    this.stdService.ViewAllStudentsInfo().subscribe(data=>{
      this.stdinfo = data;
    });
    */
  }

  getStdDetails(id:any)
  {
    this.router.navigate(['/getone', id]);
  }

  delStudent(id:any)
  {
    this.stdService.DeleteStudentInfoBasedID(id).subscribe(data=>{
      this.viewAllStudentsInfo();
    });
  }
}
