import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-newstudent',
  templateUrl: './newstudent.component.html',
  styleUrls: ['./newstudent.component.css']
})
export class NewstudentComponent implements OnInit {

  msg:string;
  constructor(
    private builder:FormBuilder,
    private stdService:StudentService,
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  studentform = this.builder.group(
    {
      id: this.builder.control('', Validators.required),
      sname: this.builder.control('', Validators.required),
      course: this.builder.control('', Validators.required),
      fees: this.builder.control('', Validators.required),
    });

    CreateNewStudent()
    {
        if(this.studentform.valid)
        {
            this.stdService.AddingNewStudent(this.studentform.value).subscribe(data=>{
              //this.msg ="New Student Info added Succcessfully..";
               
              //alert("New Student Info added Succcessfully..");
              this.router.navigate(['/vall']);
            });
        }
        else
        {
          alert("Invalid Form");
        }
    }
}
