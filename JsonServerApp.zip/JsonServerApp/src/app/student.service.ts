import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private httpclient:HttpClient) { }

  private apiUrl = "http://localhost:3000/Student";

  AddingNewStudent(stdinfo:any):Observable<Object>
  {
    return this.httpclient.post(this.apiUrl, stdinfo);
  }

  ViewAllStudentsInfo():Observable<any>
  {
    return this.httpclient.get(this.apiUrl);
  }

  GetStudentInfoBasedID(id:any):Observable<any>
  {
    return this.httpclient.get(this.apiUrl + '/' + id);
  }

  DeleteStudentInfoBasedID(id:any):Observable<any>
  {
    return this.httpclient.delete(this.apiUrl + '/' + id);
  }

}
