import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetonestdComponent } from './getonestd/getonestd.component';
import { NewstudentComponent } from './newstudent/newstudent.component';
import { ViewstudentsComponent } from './viewstudents/viewstudents.component';

const routes: Routes = [
  {path:"", component:ViewstudentsComponent},
  {path:"newstd", component:NewstudentComponent},
  {path:"vall", component:ViewstudentsComponent},
  {path:"getone/:id", component:GetonestdComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
