import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-getonestd',
  templateUrl: './getonestd.component.html',
  styleUrls: ['./getonestd.component.css']
})
export class GetonestdComponent implements OnInit {

  id:number;
  std:any;
  constructor(
    private aroute:ActivatedRoute, 
    private router:Router, 
    private stdService:StudentService) { }

  ngOnInit(): void {
    this.id = this.aroute.snapshot.params['id'];
    this.stdService.GetStudentInfoBasedID(this.id).subscribe(data=>{
      this.std = data;
    });
    //this.std = this.stdService.GetStudentInfoBasedID(this.id);
  }

  backButton()
  {
    this.router.navigate(['/vall']);
  }
}
