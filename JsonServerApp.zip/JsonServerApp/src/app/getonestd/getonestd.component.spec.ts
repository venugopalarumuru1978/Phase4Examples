import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetonestdComponent } from './getonestd.component';

describe('GetonestdComponent', () => {
  let component: GetonestdComponent;
  let fixture: ComponentFixture<GetonestdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetonestdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GetonestdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
