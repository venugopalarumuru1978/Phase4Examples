import { Injectable } from '@angular/core';
import { Users } from './users';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  userinfo:Users[] = [
    new Users("Pavan", "12345"),
    new Users("Kiran", "12345")
  ]
  constructor() { }


  LoginCheck(usr:string, pwd:string):boolean
  {
    console.log(usr + "  " + pwd);
    var  b = false;
    for(let i=0;i<this.userinfo.length;i++)
    {
      if(this.userinfo[i].username==usr && this.userinfo[i].pasword==pwd)
        b = true;
    }

    return b;
  }

  CheckLoginUser()
  {
    return sessionStorage.getItem('userdetails')!=null;
  }
}
