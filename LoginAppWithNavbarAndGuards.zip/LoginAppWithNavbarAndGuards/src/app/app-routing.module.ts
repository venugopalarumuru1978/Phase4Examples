import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminwelcomeComponent } from './adminwelcome/adminwelcome.component';
import { EmpwelcomeComponent } from './empwelcome/empwelcome.component';
import { LoginGuard } from './login.guard';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ViewAllEmpsComponent } from './view-all-emps/view-all-emps.component';

const routes: Routes = [
  {path:'', component:LoginComponent},
  {path:'login', component:LoginComponent},
  {path:'reg', component:RegisterComponent},
  {path:'awelcome', component:AdminwelcomeComponent, canActivate:[LoginGuard]},
  {path:'ewelcome', component:EmpwelcomeComponent, canActivate:[LoginGuard]},
  {path:'vall', component:ViewAllEmpsComponent,canActivate:[LoginGuard]},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
