export class Users {
    username:string;
    pasword:string;

    constructor(usr:string, pwd:string)
    {
        this.username = usr;
        this.pasword = pwd;
    }
}
