import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empwelcome',
  templateUrl: './empwelcome.component.html',
  styleUrls: ['./empwelcome.component.css']
})
export class EmpwelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
