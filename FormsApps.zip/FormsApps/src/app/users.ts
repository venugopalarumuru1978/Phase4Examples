export class Users {
    username:string;
    password:string;

    constructor(uname:string, password:string)
    {
        this.username = uname;
        this.password = password;
    }
}
