import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  msg:string="";

  constructor() { }

  ngOnInit(): void {
  }

  regForm = new FormGroup({
    personname: new FormControl('',[Validators.minLength(5), Validators.required]),
    location: new FormControl('',[Validators.required]),
    phonenumber: new FormControl('',[Validators.minLength(10), Validators.required]),
    email: new FormControl('',[Validators.required])
  });

  GetValuesFromRegForm()
  {
    this.msg = this.regForm.controls.personname.value;
    this.msg += "<br />" + this.regForm.controls.location.value;
    this.msg += "<br />" + this.regForm.controls.phonenumber.value;
    this.msg += "<br />" + this.regForm.controls.email.value;

  }
}
