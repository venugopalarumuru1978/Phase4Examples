import { Injectable } from '@angular/core';
import { Users } from './users';
@Injectable({
  providedIn: 'root'
})
export class LoginService {
  uinfo:Users[] = [
    new Users("ravi", "12345"),
    new Users("kavi", "12345"),
    new Users("bavi", "12345")
  ];
  constructor() { }

  CheckUserDetails(user:string, pwd:string) :boolean
  {
    var chk = false;
    for(let i=0;i<this.uinfo.length;i++)
    {
      if(this.uinfo[i].username==user && this.uinfo[i].password==pwd)
        chk = true;
    }
    return chk;
  }
}
