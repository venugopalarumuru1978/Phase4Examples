import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
@Component({
  selector: 'app-test-form',
  templateUrl: './test-form.component.html',
  styleUrls: ['./test-form.component.css']
})
export class TestFormComponent implements OnInit {

  msg:string = "";
  data:any;
  constructor(private builder :FormBuilder) { }

  ngOnInit(): void {
  }
  registerform = this.builder.group(
    {
      personname: this.builder.control('', Validators.required),
      email: this.builder.control('', Validators.required),
      phone: this.builder.control('', Validators.required)
    });

    getValues()
    {
      this.data = this.registerform.value;
      this.msg = this.data.personname;
      this.msg += "<br />" + this.data.email;
      this.msg += "<br />" + this.data.phone;
      
      //alert(this.data.personname);
    }
}
