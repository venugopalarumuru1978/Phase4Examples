import { Component, OnInit } from '@angular/core';
import { UploadService } from '../upload.service';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-upload-download',
  templateUrl: './upload-download.component.html',
  styleUrls: ['./upload-download.component.css']
})
export class UploadDownloadComponent implements OnInit {

  selectedFiles : FileList;
  msg: string = "";
  filesinfo : Observable<any>;

  constructor(private userve :UploadService) { }

  ngOnInit(): void {
    this.filesinfo = this.userve.getAllFiles();
  }

  BrowsedFiles(event)
  {
    this.selectedFiles = event.target.files;
    console.log(event.target.files);
    console.log(this.selectedFiles.length);
  }


  UploadAllFiles()
  {
    if(this.selectedFiles)
    {
      for(let i=0;i<this.selectedFiles.length;i++)
      {
        this.Uploadfile(this.selectedFiles[i]);
      }
    }
  }

  Uploadfile(file:File)
  {
    if(file)
    {
      this.userve.uploadFile(file).subscribe(data=>{
        console.log(data);
        this.msg = "File Uploaded...." + file.name;
        this.filesinfo = this.userve.getAllFiles();
      });
    }
  }
}
