import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class UploadService {

  constructor(private http:HttpClient) { }


private apiUrl = 'http://localhost:9090';

uploadFile(file : File) :Observable<HttpEvent<any>>{
  /*
  HttpEvent is the class which allows to specify type of event(request, response)
  For Request : HttpRequest, For Response : HttpResponse
  */

  const formData : FormData = new FormData();

  formData.append('file', file);

  const req = new HttpRequest('POST', `${this.apiUrl}/upload`, formData, {
    reportProgress:true,  // Specifies process 
    responseType:'json'
  });

  return this.http.request(req);
}

getAllFiles(): Observable<any>
{
  return this.http.get(`${this.apiUrl}/files`);
}
}
