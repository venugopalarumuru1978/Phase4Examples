import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(
    private httpClient:HttpClient
  ) { }

  private apiURL = "http://localhost:9090/api/v1/employees";

    getAllEmployees():Observable<Employee[]>{
      return this.httpClient.get<Employee[]>(`${this.apiURL}`);
    }

    AddNewEmployee(emp:Employee):Observable<Object>{
      return this.httpClient.post(`${this.apiURL}`, emp);
    }

    getEmpInfoBasedOnId(id:number):Observable<Employee>{
      return this.httpClient.get<Employee>(`${this.apiURL}/${id}`);
    }

    updateEmpInfoBasedID(id:number, emp:Employee):Observable<Object>{
      return this.httpClient.put(`${this.apiURL}/${id}`, emp);
    }

    deleteEmployeeBasedOnID(id:number):Observable<Object>{
      return this.httpClient.delete(`${this.apiURL}/${id}`);
    }
    
}
