import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-create-new-emp',
  templateUrl: './create-new-emp.component.html',
  styleUrls: ['./create-new-emp.component.css']
})
export class CreateNewEmpComponent implements OnInit {
msg:string;
  constructor(
    private builder:FormBuilder,
    private empServ:EmployeeService, 
    private router:Router
  ) { }

  ngOnInit(): void {
  }
 

  empRegForm = this.builder.group({
    id: this.builder.control('', Validators.required),
    firstName: this.builder.control('', Validators.required),
    lastName: this.builder.control('', Validators.required),
    emailId: this.builder.control('', Validators.required), 
});

newEmployee()
{
  this.empServ.AddNewEmployee(this.empRegForm.value).subscribe(data=>{
    //alert("Emp Added....");
    console.log(data);
    this.router.navigate(['/empall']);
  });
}
}
