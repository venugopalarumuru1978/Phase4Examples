import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNewEmpComponent } from './create-new-emp.component';

describe('CreateNewEmpComponent', () => {
  let component: CreateNewEmpComponent;
  let fixture: ComponentFixture<CreateNewEmpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateNewEmpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateNewEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
