import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-one-emp',
  templateUrl: './one-emp.component.html',
  styleUrls: ['./one-emp.component.css']
})
export class OneEmpComponent implements OnInit {

  id:number;
  emp:Employee;
  constructor(
    private aroute:ActivatedRoute,
    private router :Router, 
    private empServ:EmployeeService
  ) { }

  ngOnInit(): void {
    this.id = this.aroute.snapshot.params['id'];
    this.empServ.getEmpInfoBasedOnId(this.id).subscribe(data=>{
      this.emp = data;
    });
  }

  backButton()
  {
    this.router.navigate(['/empall']);
  }
}
