import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateNewEmpComponent } from './create-new-emp/create-new-emp.component';
import { OneEmpComponent } from './one-emp/one-emp.component';
import { UpdateEmpComponent } from './update-emp/update-emp.component';
import { ViewAllEmpsComponent } from './view-all-emps/view-all-emps.component';

const routes: Routes = [
  {path:'', component:ViewAllEmpsComponent},
  {path:'empall', component:ViewAllEmpsComponent},
  {path:'newemp', component:CreateNewEmpComponent},
  {path:'updateemp/:id', component:UpdateEmpComponent},
  {path:'oneemp/:id', component:OneEmpComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
