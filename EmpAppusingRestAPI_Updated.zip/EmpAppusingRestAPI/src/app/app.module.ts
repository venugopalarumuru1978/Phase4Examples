import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewAllEmpsComponent } from './view-all-emps/view-all-emps.component';
import { CreateNewEmpComponent } from './create-new-emp/create-new-emp.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UpdateEmpComponent } from './update-emp/update-emp.component';
import { OneEmpComponent } from './one-emp/one-emp.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import {FormsModule} from '@angular/forms';
import { Ng2OrderModule } from 'ng2-order-pipe';
@NgModule({
  declarations: [
    AppComponent,
    ViewAllEmpsComponent,
    CreateNewEmpComponent,
    UpdateEmpComponent,
    OneEmpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
    HttpClientModule, 
    ReactiveFormsModule, NgbModule, 
    NgxPaginationModule, Ng2SearchPipeModule, FormsModule, 
    Ng2OrderModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
