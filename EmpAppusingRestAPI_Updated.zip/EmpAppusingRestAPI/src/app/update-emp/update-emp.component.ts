import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import {FormBuilder, Validators} from '@angular/forms'
@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UpdateEmpComponent implements OnInit {
  id:number;
  emp:Employee =new Employee();
  msg:string;
  constructor(
    private aroute:ActivatedRoute, 
    private router:Router,
    private empServ:EmployeeService, 
    private builder:FormBuilder
  ) { }

  ngOnInit(): void {
    this.id = this.aroute.snapshot.params['id'];
    this.empServ.getEmpInfoBasedOnId(this.id).subscribe(data=>{
      this.emp = data;
      console.log(this.emp);
    });
  }

  empModfiyForm = this.builder.group({
    id: this.builder.control('', Validators.required),
    firstName: this.builder.control('', Validators.required),
    lastName: this.builder.control('', Validators.required),
    emailId: this.builder.control('', Validators.required), 
});

ModifyEmpDetails()
{
  this.empServ.updateEmpInfoBasedID(this.id, this.empModfiyForm.value).subscribe(data=>{
    this.router.navigate(['/empall']);
  });
}

backButton()
  {
    this.router.navigate(['/empall']);
  }
}
